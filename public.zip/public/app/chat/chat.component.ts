import { Component } from '@angular/core';
import { ChatService } from './chat.service';

@Component({
	selector: 'chat',
	templateUrl: 'app/chat/chat.template.html',
	providers: [ChatService]
})
export class ChatComponent {
	messageText: string;
	messages: Array<any>;
	roomName: string;
	inRoom: boolean;
	roomList: Array<any>;

	constructor(private _chatService: ChatService) { }

	ngOnInit() {
		this.messages = new Array();
		this.roomName = '';
		this.roomList = new Array();

		this.getRooms();
		//this.joinRoom(this.roomName);
		//joinRoom('testRoom');

	}

	sendMessage() {
		var message = {
			text: this.messageText,
			roomName:this.roomName
		};

		this._chatService.emit('chatMessage', message);
		this.messageText = ''
	}
	getRooms() {
		//used to get list of the rooms
		this._chatService.on('rrmList', (_roomList) => {

			this.roomList = _roomList;
			//remove on execution to keep it clean
			/*for (var room in _roomList) {
				// will write the rooms to the list, again long way for a reason
				this.roomList.push(room);
			}*/
			console.log(this.roomList)
			this._chatService.removeListener('rrmList');
		})
		this._chatService.emit('loadRoomList', {});
	}
	joinRoom() {
		//now that its set up, use the service to ask for room messages
		this.roomList = [];
		this._chatService.on('roomMessages', (msgs) => {
			// set a listener that kills itself
			/// migh need a for in
			var mzgs = new Array();
			this.inRoom = true;
			msgs.forEach(message => {
				// for debugging
				console.log(message);
				// alter the internal structure

				message.username = message.username.username;
				// should copy structure
				mzgs.push(message);

			});
			this.messages = mzgs;
			// now remove this listener
			this._chatService.removeListener('roomMessages');
			// add the listener to recive messages for the room
			// should be used to filter name spaceetc but itll take a bit more doing than this, doable though
			this._chatService.on('chatMessage', (msg) => {
				console.log(msg)
				if (msg.roomName === this.roomName) {
					this.messages.push(msg);
				}
			});
		});
		// now make the request
		this._chatService.emit('loadRoom', { roomName: this.roomName });
	}
	leaveRoom() {
		this.inRoom = false;
		this.messages = [];
		// clear listener and variables
		this._chatService.removeListener('chatMessage');
		// load room list
		this.getRooms();
	}
	ngOnDestroy() {
		this._chatService.removeListener('chatMessage');
	}
}